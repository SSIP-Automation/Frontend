import React from "react"
import {BrowserRouter as Router, Route,Switch } from "react-router-dom"
import './bootstrap.min.css';
import Header from "./Components/Header";
import { Col, Container, Form, Row } from "react-bootstrap";
import RegisterScreen from "./Screens/RegisterScreen";
function App() {
  return (
    <div>
      <Router>
        <Header/>
        <Container>
          <main className="py-3">
        <Switch>
          <Route path="/Register"><RegisterScreen/></Route>
              
        </Switch>
         </main>
        </Container>
      </Router>
    </div>
  );
}

export default App;
